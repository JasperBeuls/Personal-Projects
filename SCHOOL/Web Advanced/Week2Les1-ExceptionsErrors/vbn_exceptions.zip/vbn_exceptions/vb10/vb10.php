<?php

function bekijkInhoudBestand($bestand){
	if (file_exists($bestand) && is_readable($bestand)){
		$file = fopen($bestand,'r');
		$inhoud = fread($file, filesize($bestand));
		fclose($file);
		print ("<pre>$inhoud</pre>");
	}else{
		trigger_error("...",E_USER_NOTICE);
	}
}


bekijkInhoudBestand('./a.txt');
bekijkInhoudBestand('./a2.txt');

