<?php
error_reporting(E_ALL);
print($var);
print('done');
?>

