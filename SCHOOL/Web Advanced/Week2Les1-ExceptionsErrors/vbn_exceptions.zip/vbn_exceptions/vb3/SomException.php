<?php
class SomException extends Exception{
	private $index,$rijArgumenten;
	
	public function __construct($index, array $rijArgumenten ){
		$this -> rijArgumenten = $rijArgumenten;
		$this -> index = $index;
		$stringArgs= '('. implode(',',$rijArgumenten ).').';  
		$boodschap = 	'fout: som '.  $stringArgs . 
					'  De fout treedt op op index ' . 
					$index . ', de foute waarde is '. 
					' de foute waarde is '. 
					$rijArgumenten[$index];
		$this->message = $boodschap;	
	}

	public function __tostring(){
		return $this->message;
	}

	public function getFouteWaarde(){
		return $this->rijArgumenten[$this->index];
	}
}
?>

