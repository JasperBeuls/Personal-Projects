<?php
// autoload zie http://php.net/manual/en/language.oop5.autoload.php
function __autoload($class_name) {
    include __DIR__. '/'. $class_name . '.php';
}

function som (){
	$args = func_get_args();
	$s = 0;
	$cnt =0;
	foreach ($args as $v){
		if (is_integer($v)  || is_double($v)){
			$s += $v;
		}else{
			throw new SomException($cnt, $args);
		}
	$cnt ++;	
	}
	return $s;
}

try{
	print('<br/>begin try <br/>');
	$b =  som(12.333,1,3,'ZZZ',12);
	print('$b = ' . $b) ;
	print('<br/>einde try <br/>');
	}
catch (SomException $e){
	echo '<pre>';
	print	($e);
	echo '</pre>';
	}
		
echo '<br/>Einde van de php-tag<br/>';
