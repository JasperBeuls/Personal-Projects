<?php
function som (){
	$args = func_get_args();
	$s = 0;
	$cnt =0;
	foreach ($args as $v){
		if (is_integer($v) || is_double($v)){
			 $s += $v; 
		} else { 	
			$stringArgs= '('. implode(', ',$args) . ')';  
			throw new Exception("fout bij waarde $v,".
					     " dit is element $cnt ".
					     " uit de rij $stringArgs");
		}
		$cnt ++;	
	}
	return $s;
}
 

try	{
	echo '<br/>begin try <br/>';
	$a =  som(12.333,1,3, 'test',12);
	echo '$a = ' . $a ;
	echo '<br/>einde try <br/>';
} catch (Exception $e){
	print($e);
}	
 

