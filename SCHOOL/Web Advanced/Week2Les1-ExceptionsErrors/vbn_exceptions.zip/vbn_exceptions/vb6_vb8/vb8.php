<?php
error_reporting(E_ALL);
@ $f=fopen('ikbestaniet.txt','r+') or die("stop");
print('done');

