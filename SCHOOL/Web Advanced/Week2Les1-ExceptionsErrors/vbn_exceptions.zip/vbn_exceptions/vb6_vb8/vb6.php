<?php
error_reporting(E_ALL);
@ $f=fopen('ikbestaniet.txt','r+');
print('done');

