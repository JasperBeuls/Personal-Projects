<?php
$f=fopen('ikbestaniet.txt', 'r+');	
// fout wordt gegenereerd

