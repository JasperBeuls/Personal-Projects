<?php
error_reporting(E_ALL);				// rapporteer alle errors
set_error_handler('myErrorHandler');		// errors worden behandeld door
 						// myErrorHandler

function myErrorHandler($errno, $errstr, $errfile, $errline){
	throw new Exception("$errstr");
}


try{
	print ("begin");
	print($a); 				// genereert een error
	print("einde");
} catch (Exception $e){
	print($e);
}
